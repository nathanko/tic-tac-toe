package com.nathanko.tictactoe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MainActivity extends AppCompatActivity {

    private DatabaseReference database;
    DataSnapshot snapshot;
    ValueEventListener changeListener;
    Game currGame = null;
    //final String gameName = "a";


    // get from server num of players existing
    // if myNum == 1, is_myTurn = false;
    // determine who starts first???

    // follow are updates with other player via server
    int myNum = 0;
    String symbol;

   // int board[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

    int status = 0; // 0 => continue, 1 => win, 2 => lose, 3 => tie


    // action listener from server
    // commands: get myNum, update board, status win/tie

    // if receive msg up [index], updateBoard(index);
    // if receive msg win, status = 2
    // if receive msg tie, status = 3




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = FirebaseDatabase.getInstance().getReference("ttt");

        changeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                currGame = dataSnapshot.getValue(Game.class);
                Log.v("DB", "got snapshot of " + dataSnapshot.getKey() + " from pullData");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.v("DB", "The read failed: " + databaseError.getCode());
            }
        };
        database.addValueEventListener(changeListener);

        String msg = "DISCONNECTED";
        ((EditText) findViewById(R.id.gameName)).setText(msg);
    }

    public void joinGame(View v) {

        //set new game if no game
        if (currGame == null) {
            database.setValue(new Game());
        }

        if (currGame == null){
            database.addValueEventListener(changeListener);
        }

        if (currGame.playersJoined == 0) {
            myNum = 0;
            symbol = "O";
            database.child("playersJoined").setValue(++currGame.playersJoined);

            String msg = "JOINED P1";
            ((EditText) findViewById(R.id.gameName)).setText(msg);
            Log.v("DB", "joined game as 1st player 0");
        } else if (currGame.playersJoined == 1) {
            myNum = 1;
            symbol = "X";
            database.child("playersJoined").setValue(++currGame.playersJoined);

            String msg = "JOINED P2";
            ((EditText) findViewById(R.id.gameName)).setText(msg);
            Log.v("DB", "joined game as 2nd player 1");
        } else {
            //game full
            Toast.makeText(this, "Game room full. Try another time.", Toast.LENGTH_LONG).show();
        }
    }


    public void pressButton(View v) {
        if (((Button) v).getText().toString().equals("") && status == 0 && currGame.nextTurn()==myNum) {
            ((Button) v).setText(symbol);
            //update local board, forgive our dumb numbering system
            currGame.board.set(Integer.parseInt(getResources().getResourceEntryName(v.getId()).substring(1, 2)), myNum +1);
            database.setValue(currGame);

            if (is_win()) {
                status = 1;
                onWin();
            } else if (is_tie()) {
                status = 3;
                onTie();
            }
            //is_myTurn = false;
        } else {
            Toast.makeText(this, "YOU CAN'T PRESS THAT!", Toast.LENGTH_SHORT).show();
        }


    }

    /*public void joinGame(View v) {

        gameName = ((EditText) findViewById(R.id.gameName)).getText().toString();
        //database = FirebaseDatabase.getInstance().getReference("ttt");

        //if game does not exist, make it
        pullData();
        for (int i = 0; i < 1 || currGame == null; i++) {

            database.child(gameName).setValue(new Game());
            Log.v("DB", "created new game " + gameName);
            pullData();
        }
        pullData();
        pullData();
        //join game
        if (currGame.playersJoined == 0) {
            myNum = 0;
            Log.v("DB", "joined game " + gameName + " as 1st player 0");
        } else if (currGame.playersJoined == 1) {
            myNum = 1;
            Log.v("DB", "joined game " + gameName + " as 2nd player 1");
        } else {
            //game full
            Toast.makeText(this, "Game room full. Try another.", Toast.LENGTH_LONG).show();
        }
    }*/

    /*public void updateBoard(int index) { //(string[] value){

        String text = "hi";

        board[index] = 2;
        if (symbol.equals("X")) {
            text = "O";
        } else {
            text = "X";
        }
        if (index == 0) {
            ((Button) findViewById(R.id.b0)).setText(text);
        } else if (index == 1) {
            ((Button) findViewById(R.id.b1)).setText(text);
        } else if (index == 2) {
            ((Button) findViewById(R.id.b2)).setText(text);
        } else if (index == 3) {
            ((Button) findViewById(R.id.b3)).setText(text);
        } else if (index == 4) {
            ((Button) findViewById(R.id.b4)).setText(text);
        } else if (index == 5) {
            ((Button) findViewById(R.id.b5)).setText(text);
        } else if (index == 6) {
            ((Button) findViewById(R.id.b6)).setText(text);
        } else if (index == 7) {
            ((Button) findViewById(R.id.b7)).setText(text);
        } else if (index == 8) {
            ((Button) findViewById(R.id.b8)).setText(text);
        }
        is_myTurn = true;
    }*/

    public void onTie() {
        Toast.makeText(this, "Tie", Toast.LENGTH_LONG).show();
        // send message to server that game is tied AND update player2 status = 3;
    }


    public void onWin() {
        Toast.makeText(this, "CONGRATULATIONS! Throws Confetti *<|:) (/^o^)/\\(^~^)/\\(^o^\\)", Toast.LENGTH_LONG).show();
        // send message to server that other player loses AND update player2 status = 2;
    }

    public boolean is_tie() {
        for (int i = 0; i < 9; i++) {
            if (currGame.board.get(i) == 0) {
                return false;
            }
        }
        return true;
    }

    public boolean is_win() {
        /*if (board[0] == 1 && board[1] == 1 && board[2] == 1 ||
                board[3] == 1 && board[4] == 1 && board[5] == 1 ||
                board[6] == 1 && board[7] == 1 && board[8] == 1 ||
                board[0] == 1 && board[3] == 1 && board[6] == 1 ||
                board[1] == 1 && board[4] == 1 && board[7] == 1 ||
                board[2] == 1 && board[5] == 1 && board[8] == 1 ||
                board[0] == 1 && board[4] == 1 && board[8] == 1 ||
                board[2] == 1 && board[5] == 1 && board[6] == 1) {
            return true;
        }*/
        return false;
    }

}